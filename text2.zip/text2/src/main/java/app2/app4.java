package app2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class app4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String DBU = "jdbc:mysql://localhost:3306/vvv";
	private static final String DBUSER = "root";
	private static final String DBUPASS	= "yourpassword";
	
	private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DBU, DBUSER, DBUPASS);
    }
       
    public app4() {
        super();
    }
    
    static
    {
    	tool.ensureDriverLoaded();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String comment = request.getParameter("comment");
		PrintWriter out = response.getWriter();
		out.println("评论已记录");
		String sql = "INSERT INTO comment(comment1) VALUES(?)";
		try(Connection conn = getConnection();PreparedStatement stmt = conn.prepareStatement(sql))
		{
			stmt.setString(1,comment);
			stmt.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			response.getWriter().println("数据库错误"+e.getMessage());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
