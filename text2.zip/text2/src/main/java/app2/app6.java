package app2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class app6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String DBU = "jdbc:mysql://localhost:3306/vvv";
	private static final String DBUSER = "root";
	private static final String DBUPASS	= "";
	
	private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DBU, DBUSER, DBUPASS);
    }

    public app6() {
        super();
    }
    
    static
    {
    	System.out.println("999！");
    	tool.ensureDriverLoaded();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String sql = "SELECT comment1 FROM comment";
		try(Connection conn = getConnection();PreparedStatement stmt = conn.prepareStatement(sql))
		{
			try(ResultSet rs = stmt.executeQuery())
			{
				for(;rs.next();)
				{
				    String data = rs.getString("comment1");
				    out.println(data);
				}
			}
		}
		catch(SQLException e)
		{}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
