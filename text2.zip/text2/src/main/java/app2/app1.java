package app2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class app1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String DBU = "jdbc:mysql://localhost:3306/vvv";
	private static final String DBUSER = "root";
	private static final String DBUPASS	= "yourpassword";
	
	private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DBU, DBUSER, DBUPASS);
    }
    public app1() {
        super();
    }
    static
    {
    	tool.ensureDriverLoaded();
    }
    


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean[] getdenglujieguo = new boolean[10];
		response.setContentType("text/html;charset=UTF-8");
		boolean isdenglu = false;
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String sql = "SELECT userid,password FROM users WHERE userid=?";
		PrintWriter out = response.getWriter();
		out.println("接收成功");
		try(Connection conn = getConnection();PreparedStatement stmt = conn.prepareStatement(sql))
		{
			stmt.setString(1,email);
			try(ResultSet rs = stmt.executeQuery())
			{
				if(rs.next())
				{
					//找到账户
					String userspwd = rs.getString("password");
					if(userspwd.equals(password))
					{
						//密码相等登录成功
	                    out.println("<html>");
	                    out.println("<head>");
	                    out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
	                    out.println("<title>登录成功</title>");
	                    out.println("</head>");
	                    out.println("<body>");
	                    out.println("<h1>登录成功！3秒后进入主页</h1>");
	                    out.println("<script type='text/javascript'>");
	                    out.println("localStorage.setItem(\"是否登录\", \"已经登录\")");
	                    out.println("setTimeout(function() { window.location.href = 'http://43.206.235.134:8080/text2/html/index.html'; }, 3000);");
	                    out.println("</script>");
	                    out.println("</body>");
	                    out.println("</html>");
					}
					else
					{
						//密码不相等登录错误
	                    out.println("<html>");
	                    out.println("<head>");
	                    out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
	                    out.println("<title>密码错误</title>");
	                    out.println("</head>");
	                    out.println("<body>");
	                    out.println("<h1>密码错误！3秒后返回登陆界面</h1>");
	                    out.println("<script type='text/javascript'>");
	                    out.println("setTimeout(function() { window.location.href = 'http://43.206.235.134:8080/text2/about.html'; }, 3000);");
	                    out.println("</script>");
	                    out.println("</body>");
	                    out.println("</html>");
					}
				}
				else
				{
					//账户找不到
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
                    out.println("<title>用户名错误</title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<h1>用户名错误！3秒后返回登陆界面</h1>");
                    out.println("<script type='text/javascript'>");
                    out.println("setTimeout(function() { window.location.href = 'http://43.206.235.134:8080/text2/about.html'; }, 3000);");
                    out.println("</script>");
                    out.println("</body>");
                    out.println("</html>");
                    out.println(isdenglu);
				}
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			response.getWriter().println("数据库错误"+e.getMessage());
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
