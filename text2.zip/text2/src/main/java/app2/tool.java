package app2;

import java.io.IOException;
import jakarta.servlet.http.HttpServletResponse;

public class tool {
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("驱动加载成功！");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("驱动加载失败！");
        }
    }

    // 无需 HttpServletResponse 的版本，仅加载驱动
    public static void ensureDriverLoaded() {
        System.out.println("驱动已经被静态加载！");
    }

    // 需要 HttpServletResponse 的版本
    public static void ensureDriverLoaded(HttpServletResponse response) {
        try {
            response.setContentType("text/plain;charset=UTF-8");
            response.getWriter().println("驱动加载成功！");
        } catch (IOException e) {
            e.printStackTrace();
            try {
                // 再次调用 response 会有问题，应记录到日志而不是再次写入 response
                System.err.println("驱动加载失败！");
            } catch (Exception innerException) {
                innerException.printStackTrace();
            }
        }
    }
}


